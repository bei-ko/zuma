gdjs.GameCode = {};
gdjs.GameCode.GDBoardBubbleObjects1_1final = [];

gdjs.GameCode.GDBubbleQueueObjects1_1final = [];

gdjs.GameCode.GDGutterObjects1_1final = [];

gdjs.GameCode.GDPreviewBubbleObjects2_1final = [];

gdjs.GameCode.forEachIndex3 = 0;

gdjs.GameCode.forEachObjects3 = [];

gdjs.GameCode.forEachTemporary3 = null;

gdjs.GameCode.forEachTotalCount3 = 0;

gdjs.GameCode.GDBoardBubbleObjects1= [];
gdjs.GameCode.GDBoardBubbleObjects2= [];
gdjs.GameCode.GDBoardBubbleObjects3= [];
gdjs.GameCode.GDBoardBubbleObjects4= [];
gdjs.GameCode.GDBoardBubbleObjects5= [];
gdjs.GameCode.GDBoardBubbleObjects6= [];
gdjs.GameCode.GDBoardBubbleObjects7= [];
gdjs.GameCode.GDBoardBubbleObjects8= [];
gdjs.GameCode.GDSpawnerObjects1= [];
gdjs.GameCode.GDSpawnerObjects2= [];
gdjs.GameCode.GDSpawnerObjects3= [];
gdjs.GameCode.GDSpawnerObjects4= [];
gdjs.GameCode.GDSpawnerObjects5= [];
gdjs.GameCode.GDSpawnerObjects6= [];
gdjs.GameCode.GDSpawnerObjects7= [];
gdjs.GameCode.GDSpawnerObjects8= [];
gdjs.GameCode.GDAimingBubbleObjects1= [];
gdjs.GameCode.GDAimingBubbleObjects2= [];
gdjs.GameCode.GDAimingBubbleObjects3= [];
gdjs.GameCode.GDAimingBubbleObjects4= [];
gdjs.GameCode.GDAimingBubbleObjects5= [];
gdjs.GameCode.GDAimingBubbleObjects6= [];
gdjs.GameCode.GDAimingBubbleObjects7= [];
gdjs.GameCode.GDAimingBubbleObjects8= [];
gdjs.GameCode.GDMovingBubbleObjects1= [];
gdjs.GameCode.GDMovingBubbleObjects2= [];
gdjs.GameCode.GDMovingBubbleObjects3= [];
gdjs.GameCode.GDMovingBubbleObjects4= [];
gdjs.GameCode.GDMovingBubbleObjects5= [];
gdjs.GameCode.GDMovingBubbleObjects6= [];
gdjs.GameCode.GDMovingBubbleObjects7= [];
gdjs.GameCode.GDMovingBubbleObjects8= [];
gdjs.GameCode.GDInsertedBubbleObjects1= [];
gdjs.GameCode.GDInsertedBubbleObjects2= [];
gdjs.GameCode.GDInsertedBubbleObjects3= [];
gdjs.GameCode.GDInsertedBubbleObjects4= [];
gdjs.GameCode.GDInsertedBubbleObjects5= [];
gdjs.GameCode.GDInsertedBubbleObjects6= [];
gdjs.GameCode.GDInsertedBubbleObjects7= [];
gdjs.GameCode.GDInsertedBubbleObjects8= [];
gdjs.GameCode.GDPreviewBubbleObjects1= [];
gdjs.GameCode.GDPreviewBubbleObjects2= [];
gdjs.GameCode.GDPreviewBubbleObjects3= [];
gdjs.GameCode.GDPreviewBubbleObjects4= [];
gdjs.GameCode.GDPreviewBubbleObjects5= [];
gdjs.GameCode.GDPreviewBubbleObjects6= [];
gdjs.GameCode.GDPreviewBubbleObjects7= [];
gdjs.GameCode.GDPreviewBubbleObjects8= [];
gdjs.GameCode.GDLauncherObjects1= [];
gdjs.GameCode.GDLauncherObjects2= [];
gdjs.GameCode.GDLauncherObjects3= [];
gdjs.GameCode.GDLauncherObjects4= [];
gdjs.GameCode.GDLauncherObjects5= [];
gdjs.GameCode.GDLauncherObjects6= [];
gdjs.GameCode.GDLauncherObjects7= [];
gdjs.GameCode.GDLauncherObjects8= [];
gdjs.GameCode.GDGutterObjects1= [];
gdjs.GameCode.GDGutterObjects2= [];
gdjs.GameCode.GDGutterObjects3= [];
gdjs.GameCode.GDGutterObjects4= [];
gdjs.GameCode.GDGutterObjects5= [];
gdjs.GameCode.GDGutterObjects6= [];
gdjs.GameCode.GDGutterObjects7= [];
gdjs.GameCode.GDGutterObjects8= [];
gdjs.GameCode.GDBubbleQueueObjects1= [];
gdjs.GameCode.GDBubbleQueueObjects2= [];
gdjs.GameCode.GDBubbleQueueObjects3= [];
gdjs.GameCode.GDBubbleQueueObjects4= [];
gdjs.GameCode.GDBubbleQueueObjects5= [];
gdjs.GameCode.GDBubbleQueueObjects6= [];
gdjs.GameCode.GDBubbleQueueObjects7= [];
gdjs.GameCode.GDBubbleQueueObjects8= [];
gdjs.GameCode.GDGutterPainterObjects1= [];
gdjs.GameCode.GDGutterPainterObjects2= [];
gdjs.GameCode.GDGutterPainterObjects3= [];
gdjs.GameCode.GDGutterPainterObjects4= [];
gdjs.GameCode.GDGutterPainterObjects5= [];
gdjs.GameCode.GDGutterPainterObjects6= [];
gdjs.GameCode.GDGutterPainterObjects7= [];
gdjs.GameCode.GDGutterPainterObjects8= [];
gdjs.GameCode.GDBubbleClipboardObjects1= [];
gdjs.GameCode.GDBubbleClipboardObjects2= [];
gdjs.GameCode.GDBubbleClipboardObjects3= [];
gdjs.GameCode.GDBubbleClipboardObjects4= [];
gdjs.GameCode.GDBubbleClipboardObjects5= [];
gdjs.GameCode.GDBubbleClipboardObjects6= [];
gdjs.GameCode.GDBubbleClipboardObjects7= [];
gdjs.GameCode.GDBubbleClipboardObjects8= [];
gdjs.GameCode.GDBubbleExplosionObjects1= [];
gdjs.GameCode.GDBubbleExplosionObjects2= [];
gdjs.GameCode.GDBubbleExplosionObjects3= [];
gdjs.GameCode.GDBubbleExplosionObjects4= [];
gdjs.GameCode.GDBubbleExplosionObjects5= [];
gdjs.GameCode.GDBubbleExplosionObjects6= [];
gdjs.GameCode.GDBubbleExplosionObjects7= [];
gdjs.GameCode.GDBubbleExplosionObjects8= [];
gdjs.GameCode.GDScoreObjects1= [];
gdjs.GameCode.GDScoreObjects2= [];
gdjs.GameCode.GDScoreObjects3= [];
gdjs.GameCode.GDScoreObjects4= [];
gdjs.GameCode.GDScoreObjects5= [];
gdjs.GameCode.GDScoreObjects6= [];
gdjs.GameCode.GDScoreObjects7= [];
gdjs.GameCode.GDScoreObjects8= [];
gdjs.GameCode.GDCountdownObjects1= [];
gdjs.GameCode.GDCountdownObjects2= [];
gdjs.GameCode.GDCountdownObjects3= [];
gdjs.GameCode.GDCountdownObjects4= [];
gdjs.GameCode.GDCountdownObjects5= [];
gdjs.GameCode.GDCountdownObjects6= [];
gdjs.GameCode.GDCountdownObjects7= [];
gdjs.GameCode.GDCountdownObjects8= [];
gdjs.GameCode.GDHoleObjects1= [];
gdjs.GameCode.GDHoleObjects2= [];
gdjs.GameCode.GDHoleObjects3= [];
gdjs.GameCode.GDHoleObjects4= [];
gdjs.GameCode.GDHoleObjects5= [];
gdjs.GameCode.GDHoleObjects6= [];
gdjs.GameCode.GDHoleObjects7= [];
gdjs.GameCode.GDHoleObjects8= [];


gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDLauncherObjects1Objects = Hashtable.newFrom({"Launcher": gdjs.GameCode.GDLauncherObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects1Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects1Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterPainterObjects1Objects = Hashtable.newFrom({"GutterPainter": gdjs.GameCode.GDGutterPainterObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHoleObjects1Objects = Hashtable.newFrom({"Hole": gdjs.GameCode.GDHoleObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpawnerObjects1Objects = Hashtable.newFrom({"Spawner": gdjs.GameCode.GDSpawnerObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPreviewBubbleObjects1Objects = Hashtable.newFrom({"PreviewBubble": gdjs.GameCode.GDPreviewBubbleObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDAimingBubbleObjects1Objects = Hashtable.newFrom({"AimingBubble": gdjs.GameCode.GDAimingBubbleObjects1});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

{



}


{



}


{



}


{



}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


gdjs.GameCode.eventsList0(runtimeScene);
}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects3);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.GameCode.GDSpawnerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpawnerObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpawnerObjects3[i].getBehavior("SpwanerBehavior").CanSpawnBubble(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpawnerObjects3[k] = gdjs.GameCode.GDSpawnerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSpawnerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects3 */
/* Reuse gdjs.GameCode.GDBubbleQueueObjects3 */
/* Reuse gdjs.GameCode.GDGutterObjects3 */
/* Reuse gdjs.GameCode.GDSpawnerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSpawnerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSpawnerObjects3[i].getBehavior("SpwanerBehavior").SpawnBubble(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects, "GutterBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects2);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.GameCode.GDSpawnerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpawnerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpawnerObjects2[i].getBehavior("SpwanerBehavior").CanUnspawnBubble(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpawnerObjects2[k] = gdjs.GameCode.GDSpawnerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSpawnerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects2 */
/* Reuse gdjs.GameCode.GDBubbleQueueObjects2 */
/* Reuse gdjs.GameCode.GDGutterObjects2 */
/* Reuse gdjs.GameCode.GDSpawnerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDSpawnerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpawnerObjects2[i].getBehavior("SpwanerBehavior").UnspawnBubble(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects, "GutterBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPreviewBubbleObjects3Objects = Hashtable.newFrom({"PreviewBubble": gdjs.GameCode.GDPreviewBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovingBubbleObjects3Objects = Hashtable.newFrom({"MovingBubble": gdjs.GameCode.GDMovingBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPreviewBubbleObjects2Objects = Hashtable.newFrom({"PreviewBubble": gdjs.GameCode.GDPreviewBubbleObjects2});
gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AimingBubble"), gdjs.GameCode.GDAimingBubbleObjects3);
gdjs.copyArray(runtimeScene.getObjects("Launcher"), gdjs.GameCode.GDLauncherObjects3);
{for(var i = 0, len = gdjs.GameCode.GDAimingBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDAimingBubbleObjects3[i].putAroundObject((gdjs.GameCode.GDLauncherObjects3.length !== 0 ? gdjs.GameCode.GDLauncherObjects3[0] : null), 48, gdjs.evtTools.common.angleBetweenPositions((( gdjs.GameCode.GDLauncherObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDLauncherObjects3[0].getPointX("")), (( gdjs.GameCode.GDLauncherObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDLauncherObjects3[0].getPointY("")), gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AimingBubble"), gdjs.GameCode.GDAimingBubbleObjects3);
gdjs.copyArray(runtimeScene.getObjects("PreviewBubble"), gdjs.GameCode.GDPreviewBubbleObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAimingBubbleObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDAimingBubbleObjects3[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAimingBubbleObjects3[k] = gdjs.GameCode.GDAimingBubbleObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDAimingBubbleObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPreviewBubbleObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPreviewBubbleObjects3[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPreviewBubbleObjects3[k] = gdjs.GameCode.GDPreviewBubbleObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPreviewBubbleObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAimingBubbleObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Launcher"), gdjs.GameCode.GDLauncherObjects3);
/* Reuse gdjs.GameCode.GDPreviewBubbleObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.GameCode.GDSpawnerObjects3);
gdjs.GameCode.GDMovingBubbleObjects3.length = 0;

{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPreviewBubbleObjects3Objects);
}{for(var i = 0, len = gdjs.GameCode.GDAimingBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDAimingBubbleObjects3[i].getBehavior("FireBullet").Fire((gdjs.GameCode.GDAimingBubbleObjects3[i].getPointX("")), (gdjs.GameCode.GDAimingBubbleObjects3[i].getPointY("")), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovingBubbleObjects3Objects, gdjs.evtTools.common.angleBetweenPositions((( gdjs.GameCode.GDLauncherObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDLauncherObjects3[0].getPointX("")), (( gdjs.GameCode.GDLauncherObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDLauncherObjects3[0].getPointY("")), gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0)), 690, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDMovingBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDMovingBubbleObjects3[i].setAnimationName((( gdjs.GameCode.GDAimingBubbleObjects3.length === 0 ) ? "" :gdjs.GameCode.GDAimingBubbleObjects3[0].getAnimationName()));
}
}{for(var i = 0, len = gdjs.GameCode.GDAimingBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDAimingBubbleObjects3[i].setAnimationName((( gdjs.GameCode.GDPreviewBubbleObjects3.length === 0 ) ? "" :gdjs.GameCode.GDPreviewBubbleObjects3[0].getAnimationName()));
}
}{for(var i = 0, len = gdjs.GameCode.GDPreviewBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPreviewBubbleObjects3[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.randomInRange(0, (( gdjs.GameCode.GDSpawnerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnerObjects3[0].getBehavior("SpwanerBehavior").ColorCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) - 1))));
}
}}

}


{

gdjs.GameCode.GDPreviewBubbleObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDPreviewBubbleObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("PreviewBubble"), gdjs.GameCode.GDPreviewBubbleObjects3);
for (var i = 0, k = 0, l = gdjs.GameCode.GDPreviewBubbleObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDPreviewBubbleObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDPreviewBubbleObjects3[k] = gdjs.GameCode.GDPreviewBubbleObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPreviewBubbleObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDPreviewBubbleObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDPreviewBubbleObjects2_1final.indexOf(gdjs.GameCode.GDPreviewBubbleObjects3[j]) === -1 )
            gdjs.GameCode.GDPreviewBubbleObjects2_1final.push(gdjs.GameCode.GDPreviewBubbleObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDPreviewBubbleObjects2_1final, gdjs.GameCode.GDPreviewBubbleObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AimingBubble"), gdjs.GameCode.GDAimingBubbleObjects2);
/* Reuse gdjs.GameCode.GDPreviewBubbleObjects2 */
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPreviewBubbleObjects2Objects);
}{runtimeScene.getScene().getVariables().get("animationName").setString((( gdjs.GameCode.GDPreviewBubbleObjects2.length === 0 ) ? "" :gdjs.GameCode.GDPreviewBubbleObjects2[0].getAnimationName()));
}{for(var i = 0, len = gdjs.GameCode.GDPreviewBubbleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPreviewBubbleObjects2[i].setAnimationName((( gdjs.GameCode.GDAimingBubbleObjects2.length === 0 ) ? "" :gdjs.GameCode.GDAimingBubbleObjects2[0].getAnimationName()));
}
}{for(var i = 0, len = gdjs.GameCode.GDAimingBubbleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDAimingBubbleObjects2[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("animationName")));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovingBubbleObjects3Objects = Hashtable.newFrom({"MovingBubble": gdjs.GameCode.GDMovingBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDInsertedBubbleObjects3Objects = Hashtable.newFrom({"InsertedBubble": gdjs.GameCode.GDInsertedBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovingBubbleObjects3Objects = Hashtable.newFrom({"MovingBubble": gdjs.GameCode.GDMovingBubbleObjects3});
gdjs.GameCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDBoardBubbleObjects3 */
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__Contains.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__Contains.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects3 */
/* Reuse gdjs.GameCode.GDBubbleQueueObjects3 */
/* Reuse gdjs.GameCode.GDGutterObjects3 */
/* Reuse gdjs.GameCode.GDMovingBubbleObjects3 */
gdjs.GameCode.GDInsertedBubbleObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDInsertedBubbleObjects3Objects, (( gdjs.GameCode.GDGutterObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGutterObjects3[0].getPointX("")), (( gdjs.GameCode.GDGutterObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGutterObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameCode.GDInsertedBubbleObjects3.length !== 0 ? gdjs.GameCode.GDInsertedBubbleObjects3[0] : null), (gdjs.GameCode.GDBoardBubbleObjects3.length !== 0 ? gdjs.GameCode.GDBoardBubbleObjects3[0] : null));
}{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects);
}{for(var i = 0, len = gdjs.GameCode.GDInsertedBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDInsertedBubbleObjects3[i].getBehavior("InsertedBubble").Initialize(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects, "GutterBehavior", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects, "SpeedPathMovement", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovingBubbleObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDMovingBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDMovingBubbleObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleClipboardObjects2Objects = Hashtable.newFrom({"BubbleClipboard": gdjs.GameCode.GDBubbleClipboardObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleExplosionObjects2Objects = Hashtable.newFrom({"BubbleExplosion": gdjs.GameCode.GDBubbleExplosionObjects2});
gdjs.GameCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDBoardBubbleObjects2 */
gdjs.copyArray(runtimeScene.getObjects("BubbleClipboard"), gdjs.GameCode.GDBubbleClipboardObjects2);
/* Reuse gdjs.GameCode.GDBubbleQueueObjects2 */
/* Reuse gdjs.GameCode.GDGutterObjects2 */
/* Reuse gdjs.GameCode.GDInsertedBubbleObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGutterObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDGutterObjects2[i].getBehavior("GutterBehavior").Identifier((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == (( gdjs.GameCode.GDInsertedBubbleObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDInsertedBubbleObjects2[0].getBehavior("InsertedBubble").GutterIdentifier((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGutterObjects2[k] = gdjs.GameCode.GDGutterObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGutterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Smoothy__MatchBubbles.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "BubbleQueueBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, (( gdjs.GameCode.GDInsertedBubbleObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDInsertedBubbleObjects2[0].getBehavior("InsertedBubble").QueueIndex((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (( gdjs.GameCode.GDInsertedBubbleObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDInsertedBubbleObjects2[0].getBehavior("InsertedBubble").BubbleIndex((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleClipboardObjects2Objects, "ObjectStack", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects2 */
gdjs.copyArray(runtimeScene.getObjects("BubbleExplosion"), gdjs.GameCode.GDBubbleExplosionObjects2);
{runtimeScene.getScene().getVariables().get("Score").add(10 * gdjs.evtTools.object.getPickedInstancesCount(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects));
}{for(var i = 0, len = gdjs.GameCode.GDBoardBubbleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBoardBubbleObjects2[i].getBehavior("BoardBubbleBehavior").Explode(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleExplosionObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects3);
gdjs.copyArray(runtimeScene.getObjects("MovingBubble"), gdjs.GameCode.GDMovingBubbleObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovingBubbleObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("InsertedBubble"), gdjs.GameCode.GDInsertedBubbleObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDInsertedBubbleObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDInsertedBubbleObjects3[i].getBehavior("InsertedBubble").IsAnimationFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDInsertedBubbleObjects3[k] = gdjs.GameCode.GDInsertedBubbleObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDInsertedBubbleObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects3);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects3);
/* Reuse gdjs.GameCode.GDInsertedBubbleObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDInsertedBubbleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDInsertedBubbleObjects3[i].getBehavior("InsertedBubble").PlayInsertion(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects3Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects3Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("InsertedBubble"), gdjs.GameCode.GDInsertedBubbleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDInsertedBubbleObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDInsertedBubbleObjects2[i].getBehavior("InsertedBubble").IsAnimationFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDInsertedBubbleObjects2[k] = gdjs.GameCode.GDInsertedBubbleObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDInsertedBubbleObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects2);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects2);
/* Reuse gdjs.GameCode.GDInsertedBubbleObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDInsertedBubbleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDInsertedBubbleObjects2[i].getBehavior("InsertedBubble").CreateBubble(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects, "", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects6Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects6});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects6Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects6});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects6Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects6});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects7Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects7});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects7Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects7});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects7Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects7});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects7Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects7});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleExplosionObjects7Objects = Hashtable.newFrom({"BubbleExplosion": gdjs.GameCode.GDBubbleExplosionObjects7});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects6Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects6});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects6Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects6});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects6Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects6});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleClipboardObjects6Objects = Hashtable.newFrom({"BubbleClipboard": gdjs.GameCode.GDBubbleClipboardObjects6});
gdjs.GameCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDBoardBubbleObjects6, gdjs.GameCode.GDBoardBubbleObjects7);

gdjs.copyArray(gdjs.GameCode.GDBubbleQueueObjects6, gdjs.GameCode.GDBubbleQueueObjects7);

gdjs.copyArray(gdjs.GameCode.GDGutterObjects6, gdjs.GameCode.GDGutterObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Smoothy__MatchBubblesBetween.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects7Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects7Objects, "BubbleQueueBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects7Objects, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("queueIndex")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects7 */
gdjs.copyArray(runtimeScene.getObjects("BubbleExplosion"), gdjs.GameCode.GDBubbleExplosionObjects7);
/* Reuse gdjs.GameCode.GDBubbleQueueObjects7 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("areBubblesMatched"), true);
}{runtimeScene.getScene().getVariables().get("Score").add(10 * gdjs.evtTools.object.getPickedInstancesCount(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects7Objects));
}{runtimeScene.getScene().getVariables().get("Score").add(100 * (( gdjs.GameCode.GDBubbleQueueObjects7.length === 0 ) ? 0 :gdjs.GameCode.GDBubbleQueueObjects7[0].getBehavior("BubbleQueueBehavior").HeadComboLevel((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}{for(var i = 0, len = gdjs.GameCode.GDBoardBubbleObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDBoardBubbleObjects7[i].getBehavior("BoardBubbleBehavior").Explode(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleExplosionObjects7Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("areBubblesMatched"), false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects6 */
gdjs.copyArray(runtimeScene.getObjects("BubbleClipboard"), gdjs.GameCode.GDBubbleClipboardObjects6);
/* Reuse gdjs.GameCode.GDBubbleQueueObjects6 */
/* Reuse gdjs.GameCode.GDGutterObjects6 */
{gdjs.evtsExt__Smoothy__MergeQueue.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects6Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects6Objects, "BubbleQueueBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects6Objects, "BoardBubbleBehavior", "SpeedPathMovement", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("queueIndex")), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleClipboardObjects6Objects, "ObjectStack", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().get("queueIndex").sub(1);
}}

}


};gdjs.GameCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects6);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects6);
gdjs.copyArray(gdjs.GameCode.GDGutterObjects3, gdjs.GameCode.GDGutterObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Smoothy__IsQueueColliding.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects6Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects6Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects6Objects, "BoardBubbleBehavior", "SpeedPathMovement", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("queueIndex")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("areBubblesMatched"), false);
}
{ //Subevents
gdjs.GameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("queueIndex").sub(1);
}}

}


};gdjs.GameCode.eventsList9 = function(runtimeScene) {

{


let stopDoWhile_0 = false;
do {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("queueIndex")) > 0;
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.GameCode.eventsList8(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.GameCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects2);

for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.GDGutterObjects2.length;++gdjs.GameCode.forEachIndex3) {
gdjs.GameCode.GDGutterObjects3.length = 0;


gdjs.GameCode.forEachTemporary3 = gdjs.GameCode.GDGutterObjects2[gdjs.GameCode.forEachIndex3];
gdjs.GameCode.GDGutterObjects3.push(gdjs.GameCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().get("queueIndex").setNumber((( gdjs.GameCode.GDGutterObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGutterObjects3[0].getBehavior("ObjectStack").Height((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) - 1);
}
{ //Subevents: 
gdjs.GameCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects2);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects2);
{for(var i = 0, len = gdjs.GameCode.GDGutterObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGutterObjects2[i].getBehavior("GutterBehavior").UpdateMatchingQueue(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "BubbleQueueBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "BoardBubbleBehavior", "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects2);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects2);
{for(var i = 0, len = gdjs.GameCode.GDGutterObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGutterObjects2[i].getBehavior("GutterBehavior").UpdateFirstHeadPosition(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDBubbleQueueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBubbleQueueObjects2[i].getBehavior("BubbleQueueBehavior").SetBubblesSpeed(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects2Objects, "GutterBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Countdown"), gdjs.GameCode.GDCountdownObjects2);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameCode.GDScoreObjects2);
{for(var i = 0, len = gdjs.GameCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("Score")));
}
}{runtimeScene.getScene().getVariables().get("Countdown").setNumber(Math.max(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Countdown")) - gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}{for(var i = 0, len = gdjs.GameCode.GDCountdownObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDCountdownObjects2[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Countdown")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects2});
gdjs.GameCode.eventsList14 = function(runtimeScene) {

{


gdjs.GameCode.eventsList2(runtimeScene);
}


{


gdjs.GameCode.eventsList3(runtimeScene);
}


{


gdjs.GameCode.eventsList6(runtimeScene);
}


{


gdjs.GameCode.eventsList10(runtimeScene);
}


{


gdjs.GameCode.eventsList11(runtimeScene);
}


{


gdjs.GameCode.eventsList12(runtimeScene);
}


{


gdjs.GameCode.eventsList13(runtimeScene);
}


{



}


{

gdjs.GameCode.GDBoardBubbleObjects1.length = 0;

gdjs.GameCode.GDBubbleQueueObjects1.length = 0;

gdjs.GameCode.GDGutterObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDBoardBubbleObjects1_1final.length = 0;
gdjs.GameCode.GDBubbleQueueObjects1_1final.length = 0;
gdjs.GameCode.GDGutterObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Countdown")) == 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects2);
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects2);
for (var i = 0, k = 0, l = gdjs.GameCode.GDGutterObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDGutterObjects2[i].getBehavior("GutterBehavior").IsAnyBubbleReachHole(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects2Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects2Objects, "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDGutterObjects2[k] = gdjs.GameCode.GDGutterObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGutterObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDBoardBubbleObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDBoardBubbleObjects1_1final.indexOf(gdjs.GameCode.GDBoardBubbleObjects2[j]) === -1 )
            gdjs.GameCode.GDBoardBubbleObjects1_1final.push(gdjs.GameCode.GDBoardBubbleObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameCode.GDBubbleQueueObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDBubbleQueueObjects1_1final.indexOf(gdjs.GameCode.GDBubbleQueueObjects2[j]) === -1 )
            gdjs.GameCode.GDBubbleQueueObjects1_1final.push(gdjs.GameCode.GDBubbleQueueObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameCode.GDGutterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDGutterObjects1_1final.indexOf(gdjs.GameCode.GDGutterObjects2[j]) === -1 )
            gdjs.GameCode.GDGutterObjects1_1final.push(gdjs.GameCode.GDGutterObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDBoardBubbleObjects1_1final, gdjs.GameCode.GDBoardBubbleObjects1);
gdjs.copyArray(gdjs.GameCode.GDBubbleQueueObjects1_1final, gdjs.GameCode.GDBubbleQueueObjects1);
gdjs.copyArray(gdjs.GameCode.GDGutterObjects1_1final, gdjs.GameCode.GDGutterObjects1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("GameState").setString("GameOver");
}}

}


};gdjs.GameCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("GameState")) == "Playing";
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects1Objects = Hashtable.newFrom({"Gutter": gdjs.GameCode.GDGutterObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects1Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects1Objects = Hashtable.newFrom({"BubbleQueue": gdjs.GameCode.GDBubbleQueueObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects1Objects = Hashtable.newFrom({"BoardBubble": gdjs.GameCode.GDBoardBubbleObjects1});
gdjs.GameCode.asyncCallback13900644 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().get("Score").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score")));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Leaderboard", false);
}}
gdjs.GameCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GameCode.asyncCallback13900644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDBoardBubbleObjects1, gdjs.GameCode.GDBoardBubbleObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBoardBubbleObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDBoardBubbleObjects2[i].getBehavior("SpeedPathMovement").HasReachedTarget((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBoardBubbleObjects2[k] = gdjs.GameCode.GDBoardBubbleObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDBoardBubbleObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBoardBubbleObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBoardBubbleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBoardBubbleObjects2[i].hide();
}
}}

}


{

/* Reuse gdjs.GameCode.GDBoardBubbleObjects1 */
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__HasOnTop.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects1Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__HasOnTop.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects1Objects, "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBoardBubbleObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBoardBubbleObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBoardBubbleObjects1[i].getBehavior("SpeedPathMovement").HasReachedAnEnd((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBoardBubbleObjects1[k] = gdjs.GameCode.GDBoardBubbleObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBoardBubbleObjects1.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("GameState")) == "GameOver";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoardBubble"), gdjs.GameCode.GDBoardBubbleObjects1);
gdjs.copyArray(runtimeScene.getObjects("InsertedBubble"), gdjs.GameCode.GDInsertedBubbleObjects1);
{for(var i = 0, len = gdjs.GameCode.GDBoardBubbleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBoardBubbleObjects1[i].getBehavior("SpeedPathMovement").AccelarateAt(2000, 2000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDInsertedBubbleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDInsertedBubbleObjects1[i].hide();
}
}
{ //Subevents
gdjs.GameCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList19 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BubbleQueue"), gdjs.GameCode.GDBubbleQueueObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gutter"), gdjs.GameCode.GDGutterObjects1);
gdjs.copyArray(runtimeScene.getObjects("GutterPainter"), gdjs.GameCode.GDGutterPainterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hole"), gdjs.GameCode.GDHoleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Launcher"), gdjs.GameCode.GDLauncherObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.GameCode.GDSpawnerObjects1);
gdjs.GameCode.GDAimingBubbleObjects1.length = 0;

gdjs.GameCode.GDPreviewBubbleObjects1.length = 0;

{runtimeScene.getScene().getVariables().get("GameState").setString("Playing");
}{runtimeScene.getScene().getVariables().get("Countdown").setNumber(3 * 60);
}{gdjs.evtsExt__Smoothy__CreateLevel.func(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDLauncherObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterObjects1Objects, "GutterBehavior", "ObjectStack", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubbleQueueObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGutterPainterObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHoleObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpawnerObjects1Objects, "SpwanerBehavior", "ObjectStack", "SpeedPathMovement", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPreviewBubbleObjects1Objects, (( gdjs.GameCode.GDLauncherObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDLauncherObjects1[0].getPointX("")), (( gdjs.GameCode.GDLauncherObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDLauncherObjects1[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDAimingBubbleObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.GameCode.GDPreviewBubbleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPreviewBubbleObjects1[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.randomInRange(0, (( gdjs.GameCode.GDSpawnerObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnerObjects1[0].getBehavior("SpwanerBehavior").ColorCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) - 1))));
}
}{for(var i = 0, len = gdjs.GameCode.GDAimingBubbleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAimingBubbleObjects1[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.randomInRange(0, (( gdjs.GameCode.GDSpawnerObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnerObjects1[0].getBehavior("SpwanerBehavior").ColorCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) - 1))));
}
}
{ //Subevents
gdjs.GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.eventsList15(runtimeScene);
}


{


gdjs.GameCode.eventsList18(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDBoardBubbleObjects1.length = 0;
gdjs.GameCode.GDBoardBubbleObjects2.length = 0;
gdjs.GameCode.GDBoardBubbleObjects3.length = 0;
gdjs.GameCode.GDBoardBubbleObjects4.length = 0;
gdjs.GameCode.GDBoardBubbleObjects5.length = 0;
gdjs.GameCode.GDBoardBubbleObjects6.length = 0;
gdjs.GameCode.GDBoardBubbleObjects7.length = 0;
gdjs.GameCode.GDBoardBubbleObjects8.length = 0;
gdjs.GameCode.GDSpawnerObjects1.length = 0;
gdjs.GameCode.GDSpawnerObjects2.length = 0;
gdjs.GameCode.GDSpawnerObjects3.length = 0;
gdjs.GameCode.GDSpawnerObjects4.length = 0;
gdjs.GameCode.GDSpawnerObjects5.length = 0;
gdjs.GameCode.GDSpawnerObjects6.length = 0;
gdjs.GameCode.GDSpawnerObjects7.length = 0;
gdjs.GameCode.GDSpawnerObjects8.length = 0;
gdjs.GameCode.GDAimingBubbleObjects1.length = 0;
gdjs.GameCode.GDAimingBubbleObjects2.length = 0;
gdjs.GameCode.GDAimingBubbleObjects3.length = 0;
gdjs.GameCode.GDAimingBubbleObjects4.length = 0;
gdjs.GameCode.GDAimingBubbleObjects5.length = 0;
gdjs.GameCode.GDAimingBubbleObjects6.length = 0;
gdjs.GameCode.GDAimingBubbleObjects7.length = 0;
gdjs.GameCode.GDAimingBubbleObjects8.length = 0;
gdjs.GameCode.GDMovingBubbleObjects1.length = 0;
gdjs.GameCode.GDMovingBubbleObjects2.length = 0;
gdjs.GameCode.GDMovingBubbleObjects3.length = 0;
gdjs.GameCode.GDMovingBubbleObjects4.length = 0;
gdjs.GameCode.GDMovingBubbleObjects5.length = 0;
gdjs.GameCode.GDMovingBubbleObjects6.length = 0;
gdjs.GameCode.GDMovingBubbleObjects7.length = 0;
gdjs.GameCode.GDMovingBubbleObjects8.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects1.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects2.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects3.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects4.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects5.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects6.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects7.length = 0;
gdjs.GameCode.GDInsertedBubbleObjects8.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects1.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects2.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects3.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects4.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects5.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects6.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects7.length = 0;
gdjs.GameCode.GDPreviewBubbleObjects8.length = 0;
gdjs.GameCode.GDLauncherObjects1.length = 0;
gdjs.GameCode.GDLauncherObjects2.length = 0;
gdjs.GameCode.GDLauncherObjects3.length = 0;
gdjs.GameCode.GDLauncherObjects4.length = 0;
gdjs.GameCode.GDLauncherObjects5.length = 0;
gdjs.GameCode.GDLauncherObjects6.length = 0;
gdjs.GameCode.GDLauncherObjects7.length = 0;
gdjs.GameCode.GDLauncherObjects8.length = 0;
gdjs.GameCode.GDGutterObjects1.length = 0;
gdjs.GameCode.GDGutterObjects2.length = 0;
gdjs.GameCode.GDGutterObjects3.length = 0;
gdjs.GameCode.GDGutterObjects4.length = 0;
gdjs.GameCode.GDGutterObjects5.length = 0;
gdjs.GameCode.GDGutterObjects6.length = 0;
gdjs.GameCode.GDGutterObjects7.length = 0;
gdjs.GameCode.GDGutterObjects8.length = 0;
gdjs.GameCode.GDBubbleQueueObjects1.length = 0;
gdjs.GameCode.GDBubbleQueueObjects2.length = 0;
gdjs.GameCode.GDBubbleQueueObjects3.length = 0;
gdjs.GameCode.GDBubbleQueueObjects4.length = 0;
gdjs.GameCode.GDBubbleQueueObjects5.length = 0;
gdjs.GameCode.GDBubbleQueueObjects6.length = 0;
gdjs.GameCode.GDBubbleQueueObjects7.length = 0;
gdjs.GameCode.GDBubbleQueueObjects8.length = 0;
gdjs.GameCode.GDGutterPainterObjects1.length = 0;
gdjs.GameCode.GDGutterPainterObjects2.length = 0;
gdjs.GameCode.GDGutterPainterObjects3.length = 0;
gdjs.GameCode.GDGutterPainterObjects4.length = 0;
gdjs.GameCode.GDGutterPainterObjects5.length = 0;
gdjs.GameCode.GDGutterPainterObjects6.length = 0;
gdjs.GameCode.GDGutterPainterObjects7.length = 0;
gdjs.GameCode.GDGutterPainterObjects8.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects1.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects2.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects3.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects4.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects5.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects6.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects7.length = 0;
gdjs.GameCode.GDBubbleClipboardObjects8.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects1.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects2.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects3.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects4.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects5.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects6.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects7.length = 0;
gdjs.GameCode.GDBubbleExplosionObjects8.length = 0;
gdjs.GameCode.GDScoreObjects1.length = 0;
gdjs.GameCode.GDScoreObjects2.length = 0;
gdjs.GameCode.GDScoreObjects3.length = 0;
gdjs.GameCode.GDScoreObjects4.length = 0;
gdjs.GameCode.GDScoreObjects5.length = 0;
gdjs.GameCode.GDScoreObjects6.length = 0;
gdjs.GameCode.GDScoreObjects7.length = 0;
gdjs.GameCode.GDScoreObjects8.length = 0;
gdjs.GameCode.GDCountdownObjects1.length = 0;
gdjs.GameCode.GDCountdownObjects2.length = 0;
gdjs.GameCode.GDCountdownObjects3.length = 0;
gdjs.GameCode.GDCountdownObjects4.length = 0;
gdjs.GameCode.GDCountdownObjects5.length = 0;
gdjs.GameCode.GDCountdownObjects6.length = 0;
gdjs.GameCode.GDCountdownObjects7.length = 0;
gdjs.GameCode.GDCountdownObjects8.length = 0;
gdjs.GameCode.GDHoleObjects1.length = 0;
gdjs.GameCode.GDHoleObjects2.length = 0;
gdjs.GameCode.GDHoleObjects3.length = 0;
gdjs.GameCode.GDHoleObjects4.length = 0;
gdjs.GameCode.GDHoleObjects5.length = 0;
gdjs.GameCode.GDHoleObjects6.length = 0;
gdjs.GameCode.GDHoleObjects7.length = 0;
gdjs.GameCode.GDHoleObjects8.length = 0;

gdjs.GameCode.eventsList19(runtimeScene);

return;

}

gdjs['GameCode'] = gdjs.GameCode;
